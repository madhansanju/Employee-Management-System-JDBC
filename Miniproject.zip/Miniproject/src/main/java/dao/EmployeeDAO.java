package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Employee;
import util.db;

public class EmployeeDAO {

    public boolean addEmployee(Employee emp) {
        String sql = "INSERT INTO employees(name,email,department,salary,joining_date) VALUES(?,?,?,?,?)";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getDepartment());
            ps.setDouble(4, emp.getSalary());
            ps.setDate(5, emp.getJoiningDate());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean emailExists(String email) {
        String sql = "SELECT * FROM employees WHERE email=?";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void viewEmployees() {
        String sql = "SELECT * FROM employees";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                printEmployee(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchEmployee(int id) {
        String sql = "SELECT * FROM employees WHERE id=?";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                printEmployee(rs);
            } else {
                System.out.println("Employee Not Found");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchByDepartment(String department) {
        String sql = "SELECT * FROM employees WHERE department=?";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, department);
            ResultSet rs = ps.executeQuery();

            boolean found = false;

            while (rs.next()) {
                found = true;
                printEmployee(rs);
            }

            if (!found) {
                System.out.println("No employees found in this department");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean updateSalary(int id, double salary) {
        String sql = "UPDATE employees SET salary=? WHERE id=?";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDouble(1, salary);
            ps.setInt(2, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE id=?";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void countEmployees() {
        String sql = "SELECT COUNT(*) FROM employees";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Total Employees: " + rs.getInt(1));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void highestSalaryEmployee() {
        String sql = "SELECT * FROM employees ORDER BY salary DESC LIMIT 1";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Highest Salary Employee:");
                printEmployee(rs);
            } else {
                System.out.println("No employees found");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sortBySalary() {
        String sql = "SELECT * FROM employees ORDER BY salary DESC";

        try {
            Connection con = db.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                printEmployee(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void printEmployee(ResultSet rs) throws Exception {
        System.out.println(
                rs.getInt("id") + " | " +
                rs.getString("name") + " | " +
                rs.getString("email") + " | " +
                rs.getString("department") + " | " +
                rs.getDouble("salary") + " | " +
                rs.getDate("joining_date")
        );
    }


public boolean updateEmployee(int id, String name, String email,
        String department, double salary) {

String sql = "UPDATE employees SET name=?, email=?, department=?, salary=? WHERE id=?";

try {

Connection con = db.getConnection();

PreparedStatement ps = con.prepareStatement(sql);

ps.setString(1, name);
ps.setString(2, email);
ps.setString(3, department);
ps.setDouble(4, salary);
ps.setInt(5, id);

return ps.executeUpdate() > 0;

} catch (Exception e) {
e.printStackTrace();
}

return false;
}
}