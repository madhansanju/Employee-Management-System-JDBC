package main;

import java.sql.Date;

import dao.EmployeeDAO;
import model.Employee;

public class AddEmployee {

    public static void main(String[] args) {

        Employee emp = new Employee(
                "Madhan",
                "madhan@gmail.com",
                "Java Developer",
                30000,
                Date.valueOf("2026-06-19")
        );

        EmployeeDAO dao = new EmployeeDAO();

        if(dao.addEmployee(emp)) {
            System.out.println("Employee Added Successfully");
        } else {
            System.out.println("Failed to Add Employee");
        }
    }
}