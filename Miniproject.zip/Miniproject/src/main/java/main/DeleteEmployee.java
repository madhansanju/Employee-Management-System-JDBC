package main;

import dao.EmployeeDAO;

public class DeleteEmployee {

    public static void main(String[] args) {

        EmployeeDAO dao = new EmployeeDAO();

        if (dao.deleteEmployee(1)) {
            System.out.println("Employee Deleted Successfully");
        } else {
            System.out.println("Delete Failed");
        }
    }
}