package main;

import java.sql.Date;
import java.util.Scanner;

import dao.EmployeeDAO;
import dao.UserDAO;
import model.Employee;

public class EmployeeApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        EmployeeDAO empDao = new EmployeeDAO();
        UserDAO userDao = new UserDAO();

        System.out.println("===== Admin Login =====");

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if (!userDao.login(username, password)) {
            System.out.println("Invalid username or password");
            sc.close();
            return;
        }

        System.out.println("Login Successful");

        while (true) {
            System.out.println("\n===== Employee Management System =====");
            System.out.println("1. Add Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. Search Employee by ID");
            System.out.println("4. Search Employee by Department");
            System.out.println("5. Update Employee Salary");
            System.out.println("6. Delete Employee");
            System.out.println("7. Count Total Employees");
            System.out.println("8. Show Highest Salary Employee");
            System.out.println("9. Sort Employees by Salary");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter email: ");
                    String email = sc.nextLine();

                    if (empDao.emailExists(email)) {
                        System.out.println("Email already exists!");
                        break;
                    }

                    System.out.print("Enter department: ");
                    String department = sc.nextLine();

                    System.out.print("Enter salary: ");
                    double salary = sc.nextDouble();
                    sc.nextLine();

                    if (salary <= 0) {
                        System.out.println("Salary must be greater than 0");
                        break;
                    }

                    System.out.print("Enter joining date (yyyy-mm-dd): ");
                    String date = sc.nextLine();

                    try {
                        Employee emp = new Employee(name, email, department, salary, Date.valueOf(date));

                        if (empDao.addEmployee(emp)) {
                            System.out.println("Employee Added Successfully");
                        } else {
                            System.out.println("Failed to Add Employee");
                        }

                    } catch (Exception e) {
                        System.out.println("Invalid date format. Use yyyy-mm-dd");
                    }
                    break;

                case 2:
                    empDao.viewEmployees();
                    break;

                case 3:
                    System.out.print("Enter employee id: ");
                    int searchId = sc.nextInt();
                    empDao.searchEmployee(searchId);
                    break;

                case 4:
                    System.out.print("Enter department: ");
                    String searchDept = sc.nextLine();
                    empDao.searchByDepartment(searchDept);
                    break;

                case 5:
                    System.out.print("Enter employee id: ");
                    int updateId = sc.nextInt();

                    System.out.print("Enter new salary: ");
                    double newSalary = sc.nextDouble();

                    if (newSalary <= 0) {
                        System.out.println("Salary must be greater than 0");
                        break;
                    }

                    if (empDao.updateSalary(updateId, newSalary)) {
                        System.out.println("Salary Updated Successfully");
                    } else {
                        System.out.println("Update Failed");
                    }
                    break;

                case 6:
                    System.out.print("Enter employee id: ");
                    int deleteId = sc.nextInt();

                    if (empDao.deleteEmployee(deleteId)) {
                        System.out.println("Employee Deleted Successfully");
                    } else {
                        System.out.println("Delete Failed");
                    }
                    break;

                case 7:
                    empDao.countEmployees();
                    break;

                case 8:
                    empDao.highestSalaryEmployee();
                    break;

                case 9:
                    empDao.sortBySalary();
                    break;

                case 10:
                    System.out.println("Thank you!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}