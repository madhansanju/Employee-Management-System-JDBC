package main;

import dao.EmployeeDAO;

public class SearchEmployee {

    public static void main(String[] args) {

        EmployeeDAO dao = new EmployeeDAO();

        dao.searchEmployee(1);
    }
}