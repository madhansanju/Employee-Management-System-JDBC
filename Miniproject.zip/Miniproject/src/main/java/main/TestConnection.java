package main;

import util.db;

public class TestConnection {
    public static void main(String[] args) {
        db.getConnection();
    }
}