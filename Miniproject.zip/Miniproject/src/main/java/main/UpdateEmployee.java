package main;

import dao.EmployeeDAO;

public class UpdateEmployee {

    public static void main(String[] args) {

        EmployeeDAO dao = new EmployeeDAO();

        if (dao.updateSalary(1, 50000)) {
            System.out.println("Salary Updated Successfully");
        } else {
            System.out.println("Update Failed");
        }
    }
}