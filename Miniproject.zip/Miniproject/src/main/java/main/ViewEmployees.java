package main;

import dao.EmployeeDAO;

public class ViewEmployees {

    public static void main(String[] args) {

        EmployeeDAO dao = new EmployeeDAO();

        dao.viewEmployees();
    }
}